<?php
echo "Access Forbidden! Error 403";
?>